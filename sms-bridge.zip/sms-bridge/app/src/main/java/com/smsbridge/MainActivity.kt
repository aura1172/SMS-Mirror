package com.smsbridge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.*
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var paste: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 90, 40, 40); setBackgroundColor(0xFF242527.toInt()) }
        fun text(t: String, size: Float, color: Int = 0xFFF3F3EE.toInt()) = TextView(this).apply { text = t; textSize = size; setTextColor(color) }.also { col.addView(it) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setTextColor(0xFFFFFFFF.toInt()); backgroundTintList = ColorStateList.valueOf(0xFFF71735.toInt()); elevation = 10f; setOnClickListener { f() }
        }.also { col.addView(it, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 22 }) }

        text("SMS Mirror", 28f)
        info = text("", 15f, 0xFFA2A29C.toInt())
        btn("1. Scan QR from the web app") { scan() }
        paste = EditText(this).apply { hint = "…or paste the link code here"; setTextColor(0xFFF3F3EE.toInt()); setHintTextColor(0xFFA2A29C.toInt()); setSingleLine() }
        col.addView(paste)
        btn("Save pasted code") { setCode(paste.text.toString()) }
        btn("2. Grant SMS + notification permission") {
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("3. Battery: set to Unrestricted") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        btn("4. Start SMS Mirror") {
            if (Core.secret(this) == null) toast("Link a code first")
            else { Core.prefs(this).edit().putBoolean("on", true).apply(); ContextCompat.startForegroundService(this, Intent(this, BridgeService::class.java)); toast("SMS Mirror started") }
        }
        btn("Stop SMS Mirror") { Core.prefs(this).edit().putBoolean("on", false).apply(); stopService(Intent(this, BridgeService::class.java)); toast("SMS Mirror stopped") }
        btn("App settings (for 'Allow restricted settings')") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        setContentView(ScrollView(this).apply { addView(col); setBackgroundColor(0xFF242527.toInt()) })
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { super.onRequestPermissionsResult(r, p, g); refresh() }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun scan() {
        val o = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        GmsBarcodeScanning.getClient(this, o).startScan()
            .addOnSuccessListener { setCode(it.rawValue ?: "") }
            .addOnFailureListener { toast("Scan failed – paste the code instead") }
    }

    private fun setCode(raw: String) {
        val c = raw.trim().removePrefix("SMSM1:")
        if (!Regex("[A-Za-z0-9_-]{20,64}").matches(c)) return toast("That is not a valid link code")
        Core.prefs(this).edit().putString("secret", c).putLong("since", 0L).apply()
        paste.setText(""); toast("Linked ✓"); refresh()
    }

    private fun refresh() {
        val pm = getSystemService(PowerManager::class.java)
        fun y(b: Boolean) = if (b) "✓" else "✗"
        info.text = "Linked: ${y(Core.secret(this) != null)}\n" +
            "SMS permission: ${y(granted(Manifest.permission.RECEIVE_SMS) && granted(Manifest.permission.SEND_SMS))}\n" +
            "Battery unrestricted: ${y(pm.isIgnoringBatteryOptimizations(packageName))}\n" +
            "SMS Mirror switched on: ${y(Core.prefs(this).getBoolean("on", false))}"
    }
}
