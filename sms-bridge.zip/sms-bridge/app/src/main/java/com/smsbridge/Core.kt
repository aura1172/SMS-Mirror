package com.smsbridge

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Crypto + ntfy transport. Wire format must match the web app:
 *  base64( iv[12] | AES-GCM ciphertext | tag[16] ) of UTF-8 JSON.
 *  key = SHA-256("key|"+secret), topics = "smsm_" + hex(SHA-256("in|"/"out|"+secret)).take(32) */
object Core {
    const val NTFY = "https://ntfy.sh/"
    fun prefs(c: Context) = c.applicationContext.getSharedPreferences("bridge", Context.MODE_PRIVATE)
    fun secret(c: Context): String? = prefs(c).getString("secret", null)

    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    fun tin(s: String) = "smsm_" + hex(sha("in|$s")).take(32)    // phone -> other devices
    fun tout(s: String) = "smsm_" + hex(sha("out|$s")).take(32)  // other devices -> phone

    fun seal(s: String, json: String): String {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.ENCRYPT_MODE, SecretKeySpec(sha("key|$s"), "AES"), GCMParameterSpec(128, iv))
        return Base64.encodeToString(iv + ci.doFinal(json.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    fun unseal(s: String, b64: String): JSONObject? = try {
        val u = Base64.decode(b64.trim(), Base64.DEFAULT)
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.DECRYPT_MODE, SecretKeySpec(sha("key|$s"), "AES"), GCMParameterSpec(128, u, 0, 12))
        JSONObject(String(ci.doFinal(u, 12, u.size - 12), Charsets.UTF_8))
    } catch (e: Exception) { null }

    fun post(s: String, topic: String, o: JSONObject): Boolean = try {
        val c = URL(NTFY + topic).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 8000
        c.outputStream.use { it.write(seal(s, o.toString()).toByteArray(Charsets.UTF_8)) }
        val ok = c.responseCode in 200..299
        c.disconnect(); ok
    } catch (e: Exception) { false }

    /** Publish to the "incoming" topic; if the network is down, keep it in an outbox that is flushed later. */
    @Synchronized fun publishIn(c: Context, o: JSONObject) {
        val s = secret(c) ?: return
        if (post(s, tin(s), o)) return
        val a = JSONArray(prefs(c).getString("outbox", "[]")); a.put(o.toString())
        prefs(c).edit().putString("outbox", a.toString()).apply()
    }

    @Synchronized fun flushOutbox(c: Context) {
        val s = secret(c) ?: return
        val a = JSONArray(prefs(c).getString("outbox", "[]"))
        if (a.length() == 0) return
        val left = JSONArray()
        for (i in 0 until a.length()) if (!post(s, tin(s), JSONObject(a.getString(i)))) left.put(a.getString(i))
        prefs(c).edit().putString("outbox", left.toString()).apply()
    }

    fun heartbeat(c: Context) {
        val s = secret(c) ?: return
        post(s, tin(s), JSONObject().put("t", "hb").put("ts", System.currentTimeMillis()))
    }
}
