package com.smsbridge

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Foreground service: listens to the "commands" topic (long-lived stream), sends SMS on request, sends a heartbeat every 15 min. */
class BridgeService : Service() {
    @Volatile private var running = false
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("bridge", "SMS Mirror status", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, Notification.Builder(this, "bridge")
            .setSmallIcon(R.drawable.ic_notify).setContentTitle("SMS Mirror is running")
            .setContentText("Forwarding SMS to your linked devices").setContentIntent(open).setOngoing(true).build())
        if (!running) {
            running = true
            Thread { loop() }.start()
            Thread { while (running) { Core.heartbeat(this); try { Thread.sleep(15 * 60_000L) } catch (e: InterruptedException) { } } }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() { running = false; super.onDestroy() }

    private fun loop() {
        var wait = 2000L
        while (running) {
            try {
                val s = Core.secret(this)
                if (s == null) { Thread.sleep(5000); continue }
                Core.flushOutbox(this); Core.heartbeat(this)
                val since = maxOf(Core.prefs(this).getLong("since", 0L), System.currentTimeMillis() / 1000 - 3600)
                val c = URL(Core.NTFY + Core.tout(s) + "/json?since=$since").openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 100_000   // ntfy sends a keep-alive every 45 s
                c.inputStream.bufferedReader().useLines { lines ->
                    wait = 2000L
                    for (l in lines) { if (!running) break; handle(s, l) }
                }
            } catch (e: Exception) { }
            if (running) { try { Thread.sleep(wait) } catch (e: InterruptedException) { }; wait = minOf(wait * 2, 60_000L) }
        }
    }

    private fun handle(s: String, line: String) {
        val e = try { JSONObject(line) } catch (x: Exception) { return }
        if (e.optString("event") != "message") return
        Core.prefs(this).edit().putLong("since", e.optLong("time")).apply()
        val o = Core.unseal(s, e.optString("message")) ?: return       // wrong key / tampered -> ignored
        when (o.optString("t")) {
            "ping" -> Core.heartbeat(this)
            "send" -> send(o)
        }
    }

    @Synchronized private fun firstTime(id: String): Boolean {      // never send the same command twice
        val p = Core.prefs(this); val a = JSONArray(p.getString("done", "[]"))
        for (i in 0 until a.length()) if (a.getString(i) == id) return false
        val n = JSONArray(); for (i in maxOf(0, a.length() - 199) until a.length()) n.put(a.getString(i)); n.put(id)
        p.edit().putString("done", n.toString()).apply(); return true
    }

    private fun send(o: JSONObject) {
        val id = o.optString("id"); val to = o.optString("to"); val body = o.optString("b"); val ts = o.optLong("ts")
        if (id.isEmpty() || !firstTime(id)) return
        fun report(st: String) = Core.publishIn(this, JSONObject().put("t", "st").put("id", id).put("s", st).put("to", to).put("b", body).put("ts", ts))
        if (System.currentTimeMillis() - ts > 3_600_000L) return report("failed")          // too old: phone was offline > 1 h
        if (!Regex("\\+?\\d{3,15}").matches(to) || body.isBlank()) return report("failed")
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return report("failed")
        try {
            val sm = getSystemService(SmsManager::class.java)
            val parts = sm.divideMessage(body)
            val sent = ArrayList<PendingIntent>()
            for (i in parts.indices) sent.add(PendingIntent.getBroadcast(this, 0,
                Intent(this, SentReceiver::class.java).setAction("sent.$id.$i")
                    .putExtra("id", id).putExtra("to", to).putExtra("b", body).putExtra("ts", ts).putExtra("n", parts.size),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            sm.sendMultipartTextMessage(to, null, parts, sent, null)
        } catch (e: Exception) { report("failed") }
    }
}
