package com.smsbridge

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** Every incoming SMS -> encrypted event on the "incoming" topic. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Core.secret(c) == null) return
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val ts = System.currentTimeMillis()
        val grouped = parts.groupBy { it.originatingAddress ?: "Unknown" }
        val pr = goAsync()
        Thread {
            try {
                for ((addr, list) in grouped) {
                    val body = list.joinToString("") { it.messageBody ?: "" }.take(900)  // keeps the payload under ntfy's 4096-byte limit
                    val id = "i" + ts.toString(36) + (addr + body).hashCode().toUInt().toString(36)
                    Core.publishIn(c, JSONObject().put("t", "sms").put("id", id).put("a", addr).put("b", body).put("ts", ts))
                }
            } finally { pr.finish() }
        }.start()
    }
}

/** Reports delivery of an outgoing SMS to the radio ("sent") or failure. */
class SentReceiver : BroadcastReceiver() {
    companion object {
        val okParts = ConcurrentHashMap<String, Int>()
        val failed: MutableSet<String> = ConcurrentHashMap.newKeySet()
    }
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val status: String
        if (resultCode == Activity.RESULT_OK) {
            val n = (okParts[id] ?: 0) + 1; okParts[id] = n
            if (n < i.getIntExtra("n", 1)) return
            status = "sent"
        } else {
            if (!failed.add(id)) return
            status = "failed"
        }
        val o = JSONObject().put("t", "st").put("id", id).put("s", status)
            .put("to", i.getStringExtra("to")).put("b", i.getStringExtra("b")).put("ts", i.getLongExtra("ts", 0L))
        val pr = goAsync()
        Thread { try { Core.publishIn(c, o) } finally { pr.finish() } }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Core.secret(c) != null && Core.prefs(c).getBoolean("on", false))
            ContextCompat.startForegroundService(c, Intent(c, BridgeService::class.java))
    }
}
